<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class ProcessoAdministrativo extends Model
{
    protected $table = 'processo_administrativo';

}
