<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class CidCategoria extends Model
{
    protected $table = 'cid_categoria';
}
