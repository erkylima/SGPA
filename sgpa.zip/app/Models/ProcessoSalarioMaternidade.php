<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class ProcessoSalarioMaternidade extends Model
{
    protected $table = 'processo_salario_maternidade';
}
