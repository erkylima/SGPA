<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class CidSubcategoria extends Model
{
    protected $table = 'cid_subcategoria';
}
