<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class ProcessoBpcloasDeficiente extends Model
{
    protected $table = 'processo_bpcloas_deficiente';
}
