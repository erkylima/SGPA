<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class ProcessoAposentadoria extends Model
{
    protected $table = 'processo_aposentadoria';
}
