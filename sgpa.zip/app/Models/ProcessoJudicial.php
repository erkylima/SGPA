<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class ProcessoJudicial extends Model
{
    protected $table = "processo_judicial";
}
