<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class ProcessoAuxilioAcidente extends Model
{
    protected $table = "processo_auxilio_acidente";
}
