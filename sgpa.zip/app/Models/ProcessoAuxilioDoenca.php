<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class ProcessoAuxilioDoenca extends Model
{
    protected $table = 'processo_auxilio_doenca';
}
